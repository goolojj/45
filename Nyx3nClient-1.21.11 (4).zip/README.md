# NYX3N Client v3.0 — HT3 Combat & AI Edition (Minecraft 1.21.11 Fabric)

## Controls (Works on PC & MJLauncher Mobile!)
- **`M` Key**: Open **NYX3N Client ClickGUI Menu** (22 toggles across 2 pages!)
- **`N` Key**: Quick toggle **Master AI ON / OFF**
- **Chat Commands (100% Backup!)**: Type `.menu` to open Menu, `.on` to turn AI ON, `.off` to turn AI OFF!

## HT3 Pro Combat & 22 Features
- **HT3 Jump-Crit + W-Tap Combo**: Jumps on 70%+ cooldown and lands 1.5x Critical Hits on exact downward fall ticks!
- **HT3 1v4 Crowd Kiting & Circle-Strafe**: When 2–4 zombies attack together, automatically back-pedals + circle-strafes away from the pack so you NEVER get surrounded, lining mobs up for Sweeping Edge crits!
- **Auto-Shield Block**: Raises offhand shield against incoming hits/arrows while weapon cooldown recharges, then drops shield to crit!
- **Instant Attacker Retaliation**: Immediately fights back against ANY mob that hits you (Zombies, Spiders, Skeletons, Slimes, Phantoms, Pillagers).
- **Anti-Creeper 12m Radar**, **Iron Golem 3-Block Pillar Cheese**, **Fixed Tree Chopper + Front Leaf Cutter**, **Auto Mining**, **Auto Build House**, **Auto-Eat**, **Auto-Tool**, **Auto-Collect Drops**, **Water Swim Rescue**, **Low-HP Retreat**, **Night Alert**, **HUD Position Switcher**, and **Panic Stop All**.
