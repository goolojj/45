package com.nyx3n.client;

public class Nyx3nConfig {
    // Page 1: Core AI & HT3 Combat
    public boolean masterEnabled = false;
    public boolean treeChopper = true;
    public boolean autoMining = false;
    public boolean buildHouse = false;
    public boolean autoCombat = true;
    public boolean ht3CritCombo = true;
    public boolean ht3CrowdStrafe = true;
    public boolean autoShield = true;
    public boolean antiCreeper = true;
    public boolean ironGolemCheese = false;

    // Page 2: Smart Survival, Movement & HUD
    public boolean autoEat = true;
    public boolean autoTool = true;
    public boolean autoCollectDrops = true;
    public boolean autoSprint = true;
    public boolean autoJump = true;
    public boolean waterRescue = true;
    public boolean lowHpRetreat = true;
    public boolean leafCleaner = true;
    public boolean mobRadarHud = true;
    public boolean nightAlert = true;

    // HUD Position: 0 = TOP_RIGHT (MJLauncher friendly), 1 = TOP_CENTER, 2 = TOP_LEFT
    public int hudPosition = 0;

    public String getHudPositionLabel() {
        return switch (hudPosition) {
            case 0 -> "TOP-RIGHT";
            case 1 -> "TOP-CENTER";
            default -> "TOP-LEFT";
        };
    }

    public void cycleHudPosition() {
        hudPosition = (hudPosition + 1) % 3;
    }

    public void panicStopAll() {
        masterEnabled = false;
        treeChopper = false;
        autoMining = false;
        buildHouse = false;
        autoCombat = false;
        ironGolemCheese = false;
    }
}
